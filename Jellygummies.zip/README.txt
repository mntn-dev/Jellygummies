Jellygummies.exe (v0.1/Jun 2018)
================================

Sam Lyon's Jellygummies <https://jellygummies.com/> on the Windows Desktop

* left double-click changes image
* mouse-wheel (up/down) changes transparency
* right-click ends

*------------------------------------------*
| Get the .exe:                            |
| https://github.com/mntn-dev/Jellygummies |
*------------------------------------------*




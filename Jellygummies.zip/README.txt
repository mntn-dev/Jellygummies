*---------------------------*
/ Sam Lyon's Jellygummies   /
/ on the Windows(r) Desktop /
*---------------------------*

v0.2 -- July 2018


* left double-click changes gif
* mouse-wheel (up/down) changes transparency
* right-click ends

.JGX files include juicy models, just drag&drop 'em into .exe or
current screen gif animation to load.


> https://github.com/mntn-dev/Jellygummies
> https://www.jellygummies.com
> https://www.mn.tn

 